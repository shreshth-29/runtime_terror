from django.shortcuts import render
from app.models import recipe,form
from . import forms
from django.http import HttpResponse

def index(request):
    form = forms.formname
    if request.method == 'POST':
        print("post")
        form = forms.formname(request.POST)

        if form.is_valid():
            search_req = form.cleaned_data['search']
            cuisine = form.cleaned_data['cuisine']
            time = form.cleaned_data['Time']
            print (cuisine)

            req = '%'+search_req+'%'
            print(req)
            parameters = [req]

            query = 'select * from recipe where name like %s '
            if cuisine != 'none':
                query = query + ' and cuisine = %s '
                parameters.append(cuisine)

            if (time != 'none'):
                query = query + ' and total_time <= %s'
                parameters.append(time)

            print (query)
            print (parameters)
            list = recipe.objects.raw(query, parameters)

            #list = recipe.objects.all()
            dict = {'access':list}

        return render(request, 'webpage2.html',context = dict)
    #form.save(commit = True)

    return render(request, 'index.html',{'form':form})

def result(request):
    return render(request, 'webpage2.html')

def recipe_pg(request):

    x = request.GET.get('id', '')
    print(x)

    list1 = recipe.objects.filter(id = x)
    dict_1 = {'final':list1}
    print(list1)


    return render(request, 'webpage3.html',context = dict_1)

def feed(request):
    form = forms.feedback

    if request.method == 'POST':
        form = forms.feedback(request.POST)

        if form.is_valid():
            print("validation successful")
            print('NAME: ',form.cleaned_data['name'])
            print('EMAIL: ',form.cleaned_data['email'])
            print('TEXT: ',form.cleaned_data['text'])

            form.save(commit = True)

            dict_2 = {'msg':'feedback submitted! Thanks'}

        return render(request,'form.html',context = dict_2)
    return render(request,'form.html',{'form':form})




# Create your views here.
