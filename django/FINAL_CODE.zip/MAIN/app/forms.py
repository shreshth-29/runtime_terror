from django import forms
from app.models import recipe
from app.models import form

class formname (forms.ModelForm):
    search = forms.CharField(max_length = 200)
    cuisine = forms.ChoiceField(choices= [('none','none'),('chinese', 'Chinese'), ('indian','Indian'),('italian','Italian'),('thai','Thai')])
    Time = forms.ChoiceField(choices= [('none','none'),('30','Under 30mins'), ('60','Under 1hr'),('120','Under 2hrs')])#('Under 3hrs','Under 3hrs)',('Beyond 3hr','Beyond 3hrs')]
    #Difficulty = forms.ChoiceField(choices= [('Easy','Easy'),('Medium','Medium'),('Hard','Hard')])


    class Meta:
        model = recipe
        fields = ("search",)


class feedback (forms.ModelForm):
    name = forms.CharField(max_length = 200)
    email = forms.EmailField(max_length = 200)
    text = forms.CharField(widget = forms.Textarea)

    class Meta:
        model = form
        fields = ("name","email","text",)
