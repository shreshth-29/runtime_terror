from django.contrib import admin
from app.models import recipe,form

admin.site.register(recipe)
admin.site.register(form)

# Register your models here.
