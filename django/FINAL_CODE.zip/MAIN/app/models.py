from django.db import models


class recipe(models.Model):
    id = models.IntegerField(primary_key = True)
    name = models.CharField(max_length = 500)
    course = models.CharField(max_length = 500)
    cuisine = models.CharField(max_length = 500)
    servings = models.IntegerField()
    calories = models.CharField(max_length = 500)
    total_time = models.IntegerField()
    ingredients = models.CharField(max_length = 200)
    instructions = models.CharField(max_length = 200)
    keywords = models.CharField(max_length = 200)

    class Meta:
       managed = False
       db_table = 'recipe'

    def __str__(self):

        return self.name

class form(models.Model):
    name = models.CharField(max_length = 200)
    email = models.EmailField(max_length = 200)
    text = models.CharField(max_length = 10000)


    class Meta:
        managed = False
        db_table = 'feedback'

    def __str__(self):
        return self.name
# Create your models here.
